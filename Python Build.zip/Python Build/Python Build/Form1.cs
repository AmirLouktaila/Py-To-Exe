﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Python_Build
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openapp = new OpenFileDialog();
            openapp.Filter = "Python Script (*.py)|*.py";

            if (openapp.ShowDialog()==System.Windows.Forms.DialogResult.OK)
            {
                string pathapp = openapp.FileName;
                guna2TextBox1.Text = pathapp;
            }
              


           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            gunaComboBox1.SelectedIndex = 0;
            

        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(gunaComboBox1.SelectedIndex==0)
            {
                label2.Text = "Select Language : ";
                message.Text = "when activate this \n Hide console when launch app !";
                CheckBox1.Text = "No Console";
                CheckBox2.Text = "Add Icon";
                label1.Text = "Script Location :";
                label4.Text = "icon Location : ";
                guna2Button1.Text = "Browser";
                guna2Button2.Text = "Browser";
                guna2Button3.Text = "Convert";
                guna2Button4.Text = "Exit";
                label5.Text = "save location:";
                

            }
            else if(gunaComboBox1.SelectedIndex == 1)
            {
                label2.Text = "اختيار اللغة ";
                message.Text = "عندما تفعل هذا الخيار لن يظهر موجه الاوامر عند تشغيل تطبيقك";
                CheckBox1.Text = "اخفاء موجه الاوامر عند تشغيل";
                CheckBox2.Text = "اضافة ايقونة";
                label1.Text = "موقع هذا سيناريو";
                label4.Text = "موقع الايقونة";
                guna2Button1.Text = "تصفح";
                guna2Button2.Text = "تصفح";
                guna2Button3.Text = "تحويل";
                guna2Button4.Text = "خروج";
                label5.Text="حفظ الموقع:";
            }
            else if (gunaComboBox1.SelectedIndex == 2)
            {
                label2.Text = "Выберите язык : ";
                message.Text = "при активации этого \n Скрыть консоль при запуске приложения!";
                CheckBox1.Text = "Нет консоли";
                CheckBox2.Text = "Добавить значок";
                label1.Text = "Расположение скрипта:";
                label4.Text = "расположение значка:";
                guna2Button1.Text = "Браузер";
                guna2Button2.Text = "Браузер";
                guna2Button3.Text = "Конвертировать";
                guna2Button4.Text = "Выход";
                label5.Text = "сохранить местоположение:";

            }
            else if (gunaComboBox1.SelectedIndex == 3)
            {
                label2.Text = "Sprache auswählen :";
                message.Text = "bei Aktivierung \n Konsole beim Start der App ausblenden !";
                CheckBox1.Text = "Keine Konsole";
                CheckBox2.Text = "Symbol hinzufügen";
                label1.Text = "Speicherort des Skripts:";
                label4.Text = "Symbol Ort:";
                guna2Button1.Text = "Browser";
                guna2Button2.Text = "Browser";
                guna2Button3.Text = "Konvertieren";
                guna2Button4.Text = "Ausgang";
                label5.Text = "sicherer Ort:";
            }
            else if (gunaComboBox1.SelectedIndex == 4)
            {
                label2.Text = "Seleccione el idioma :";
                message.Text = "cuando active esta \n ¡Ocultar consola cuando inicie la aplicación!";
                CheckBox1.Text = "Sin consola";
                CheckBox2.Text = "Añadir icono";
                label1.Text = "Script Location :";
                label4.Text = "Ubicación del guión:";
                guna2Button1.Text = "Navegador";
                guna2Button2.Text = "Navegador";
                guna2Button3.Text = "Convertir";
                guna2Button4.Text = "Salida";
                label5.Text = "guardar dirección:";

            }
            else
            {

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(CheckBox2.Checked==true)
            {
                guna2Button2.Enabled = true;
            }
            else
            {
                guna2Button2.Enabled = false;
            }

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openicon = new OpenFileDialog();
            openicon.Filter = "File  (*.ico)|*.ico";
            if (openicon.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                string pathapp = openicon.FileName;
                guna2TextBox2.Text = pathapp;
            }

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
         
          try
            {
                

                if (CheckBox1.Checked == true && CheckBox2.Checked == true)
            {
                    

                   ProcessStartInfo psi = new ProcessStartInfo("cmd");
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.CreateNoWindow = true;
                psi.RedirectStandardInput = true;
                   var proc = Process.Start(psi);
                 
                proc.StandardInput.WriteLine("pyinstaller --onefile" + " --noconsole --distpath " + '"' + guna2TextBox3.Text + '"' + " -i " + '"' + guna2TextBox2.Text + '"'+" " + '"' + guna2TextBox1.Text + '"');
                proc.StandardInput.WriteLine("exit");
                string s =proc.StandardOutput.ReadToEnd();
                textBox1.Text = s;


                    MessageBox.Show("Mission completed successfully");
                
                }
            
            else if (CheckBox1.Checked == true)
            {
              
                ProcessStartInfo psi = new ProcessStartInfo("cmd");
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.CreateNoWindow = true;
                psi.RedirectStandardInput = true;
                var proc = Process.Start(psi);
                proc.StandardInput.WriteLine("pyinstaller --onefile --noconsole" + " --distpath " +'"' + guna2TextBox3.Text+ '"' +" " +'"' + guna2TextBox1.Text + '"');
                proc.StandardInput.WriteLine("exit");
                string s = proc.StandardOutput.ReadToEnd();
                textBox1.Text = s;
                    MessageBox.Show("Mission completed successfully");

                }
                else if (CheckBox2.Checked == true)
            {
              
                ProcessStartInfo psi = new ProcessStartInfo("cmd");
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.CreateNoWindow = true;
                psi.RedirectStandardInput = true;
                var proc = Process.Start(psi);
                proc.StandardInput.WriteLine("pyinstaller --onefile" + " --distpath " +'"'+guna2TextBox3.Text+'"' + " "  +"-i "+'"'+guna2TextBox2.Text +'"'+" "+ '"' + guna2TextBox1.Text + '"');
                proc.StandardInput.WriteLine("exit");
                string s = proc.StandardOutput.ReadToEnd();
                textBox1.Text = s;
                    MessageBox.Show("Mission completed successfully");


                }

                else
            {
             
                ProcessStartInfo psi = new ProcessStartInfo("cmd");
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.CreateNoWindow = true;
                psi.RedirectStandardInput = true;
                var proc = Process.Start(psi);
                proc.StandardInput.WriteLine("pyinstaller --onefile --console" + " --distpath " + '"' + guna2TextBox3.Text+" " + '"' + '"' + guna2TextBox1.Text + '"');
                proc.StandardInput.WriteLine("exit");
                string s = proc.StandardOutput.ReadToEnd();
                textBox1.Text = s;
                    MessageBox.Show("Mission completed successfully");
                }
            }
            catch
            {
                textBox1.Text = "Mission Failed";
            }

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
  

        }

        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            string folderPath = "";
            FolderBrowserDialog directchoosedlg = new FolderBrowserDialog();
            if (directchoosedlg.ShowDialog() == DialogResult.OK)
            {
                folderPath = directchoosedlg.SelectedPath;
                guna2TextBox3.Text = folderPath;
                guna2Button3.Enabled = true;
            }
        }

        private void guna2WinProgressIndicator1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2WinProgressIndicator1_Click_1(object sender, EventArgs e)
        {

        }

    }
}

